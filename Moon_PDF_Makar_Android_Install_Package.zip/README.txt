Moon PDF Makar — Offline Web App

This package is an installable PWA, not a signed Android APK.
For installation, the files must be hosted on an HTTPS website:
1. Open the hosted site in Chrome on Android.
2. Open Chrome menu (⋮) and choose "Install app" or "Add to Home screen".
3. Open it from the home screen. The app shell is cached for offline use.

The PDF export uses Android/Chrome Print > Save as PDF.
